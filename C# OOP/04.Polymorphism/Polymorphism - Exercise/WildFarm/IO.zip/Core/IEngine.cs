﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Core
{
    public interface IEngine
    {
        void Start();
    }
}
