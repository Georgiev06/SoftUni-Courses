﻿namespace CopyDirectory
{
    using System;
    using System.IO;
    public class CopyDirectory
    {
        static void Main()
        {
            string inputPath = @$"{Console.ReadLine()}";
            string outputPath = @$"{Console.ReadLine()}";

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            string[] filePaths = Directory.GetFiles(inputPath);

            foreach (var filename in filePaths)
            {
                string file = filename.ToString();

                string str = Path.Combine(outputPath, file);

                if (!File.Exists(str))
                {
                    File.Copy(file, str);
                }
            }
        }
    }
}

